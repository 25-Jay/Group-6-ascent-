using NUnit.Framework;

public class PathPlaceholder 
{
    [Test]
    public void PlaceHolderTest()
    {
        Assert.Pass("Path tests are in a separate package.");
    }
}
